import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/configs_provider.dart';
import '../widgets/config_card.dart';

class ConfigsScreen extends StatelessWidget {
  const ConfigsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ConfigsProvider>();
    final items = p.filtered;
    return Scaffold(
      appBar: AppBar(title: Text('کانفیگ‌های سالم (${items.length})')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'جستجو (نام، آدرس، کشور)…',
                border: OutlineInputBorder(),
                isDense: true,
              ),
              onChanged: p.setSearch,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Wrap(
              spacing: 8,
              children: [
                for (final g in const {
                  'v2ray': 'V2Ray',
                  'openvpn': 'OpenVPN',
                  'sstp': 'SSTP'
                }.entries)
                  FilterChip(
                    label: Text(g.value),
                    selected: p.activeGroups.contains(g.key),
                    onSelected: (_) => p.toggleGroup(g.key),
                  ),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'هنوز کانفیگ سالمی وجود ندارد.\nاز صفحه اصلی «شروع بروزرسانی» را بزنید.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: items.length,
                    itemBuilder: (_, i) => ConfigCard(config: items[i]),
                  ),
          ),
        ],
      ),
    );
  }
}
