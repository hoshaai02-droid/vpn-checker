import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/configs_provider.dart';
import '../providers/settings_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: context.read<SettingsProvider>().token);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _confirmClear(BuildContext context) async {
    final configs = context.read<ConfigsProvider>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('پاک کردن دیتابیس'),
        content: const Text('همه کانفیگ‌های ذخیره‌شده حذف می‌شوند. مطمئن هستید؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('انصراف')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) await configs.clearAll();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsProvider>();
    final c = context.watch<ConfigsProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('توکن گیت‌هاب (اختیاری)',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text(
              'برای بالاتر رفتن سقف درخواست‌ها. به‌صورت رمزشده در حافظه امن گوشی ذخیره می‌شود.'),
          const SizedBox(height: 8),
          TextField(
            controller: _ctrl,
            obscureText: true,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
                border: OutlineInputBorder(), hintText: 'ghp_...'),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: FilledButton(
              onPressed: () async {
                final messenger = ScaffoldMessenger.of(context);
                await s.saveToken(_ctrl.text);
                messenger.showSnackBar(const SnackBar(content: Text('ذخیره شد')));
              },
              child: const Text('ذخیره توکن'),
            ),
          ),
          const Divider(height: 32),
          Text('بروزرسانی خودکار',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('دستی')),
              ButtonSegment(value: 6, label: Text('هر ۶ ساعت')),
              ButtonSegment(value: 24, label: Text('هر ۲۴ ساعت')),
            ],
            selected: {s.intervalHours},
            onSelectionChanged: (v) => s.setInterval(v.first),
          ),
          const SizedBox(height: 8),
          const Text(
              'بروزرسانی در پس‌زمینه توسط اندروید زمان‌بندی می‌شود و ممکن است به خاطر حالت صرفه‌جویی باتری دیرتر اجرا شود.'),
          const Divider(height: 32),
          Text('تعداد کانفیگ ذخیره‌شده: ${c.storedCount}'),
          const SizedBox(height: 8),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: OutlinedButton.icon(
              onPressed: () => _confirmClear(context),
              icon: const Icon(Icons.delete_outline),
              label: const Text('پاک کردن دیتابیس'),
            ),
          ),
        ],
      ),
    );
  }
}
