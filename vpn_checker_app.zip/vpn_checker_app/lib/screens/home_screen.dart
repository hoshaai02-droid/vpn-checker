import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/configs_provider.dart';
import '../widgets/progress_dialog.dart';
import '../widgets/stats_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _start(BuildContext context) {
    context.read<ConfigsProvider>().refresh();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const ProgressDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ConfigsProvider>();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('VPN Config Checker')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                  child: StatsCard(
                      title: 'کل پیدا شده',
                      value: '${p.found}',
                      icon: Icons.search,
                      color: cs.primary)),
              Expanded(
                  child: StatsCard(
                      title: 'سالم',
                      value: '${p.okCount}',
                      icon: Icons.check_circle,
                      color: Colors.green)),
              Expanded(
                  child: StatsCard(
                      title: 'ناموفق',
                      value: '${p.failed}',
                      icon: Icons.cancel,
                      color: cs.error)),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 64,
            child: FilledButton.icon(
              onPressed: p.running ? null : () => _start(context),
              icon: const Icon(Icons.refresh, size: 28),
              label: Text(p.running ? 'در حال بروزرسانی…' : 'شروع بروزرسانی',
                  style: const TextStyle(fontSize: 18)),
            ),
          ),
          const SizedBox(height: 20),
          if (p.running || p.stage.isNotEmpty) ...[
            LinearProgressIndicator(value: p.progress <= 0 ? null : p.progress),
            const SizedBox(height: 8),
            Text('${(p.progress * 100).clamp(0, 100).toStringAsFixed(0)}٪  •  ${p.stage}'),
          ],
          if (p.error != null) ...[
            const SizedBox(height: 16),
            Card(
              color: cs.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(p.error!,
                    style: TextStyle(color: cs.onErrorContainer)),
              ),
            ),
          ],
          if (p.warnings.isNotEmpty) ...[
            const SizedBox(height: 8),
            ExpansionTile(
              title: Text('هشدارها (${p.warnings.length})'),
              children: [
                for (final w in p.warnings.take(15))
                  ListTile(dense: true, title: Text(w)),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
