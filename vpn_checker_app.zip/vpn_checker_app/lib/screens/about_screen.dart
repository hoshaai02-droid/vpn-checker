import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../utils/constants.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('درباره')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(AppConstants.appName,
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          const Text(
              'این برنامه کانفیگ‌های عمومی V2Ray، OpenVPN و SSTP را از گیت‌هاب جمع می‌کند، '
              'آن‌ها را تست می‌کند و فقط موارد سالم را نشان می‌دهد.\n\n'
              'توجه: کانفیگ‌های رایگان عمومی ممکن است ناامن، کند یا ناپایدار باشند. '
              'برای کارهای حساس (بانک، ایمیل، ...) از آن‌ها استفاده نکنید.'),
          const SizedBox(height: 16),
          Text('مخازن منبع', style: Theme.of(context).textTheme.titleMedium),
          for (final r in AppConstants.repos)
            ListTile(
              dense: true,
              leading: const Icon(Icons.link),
              title: Text(r, textDirection: TextDirection.ltr),
              onTap: () async {
                try {
                  await launchUrl(Uri.parse('https://github.com/$r'),
                      mode: LaunchMode.externalApplication);
                } catch (_) {}
              },
            ),
        ],
      ),
    );
  }
}
