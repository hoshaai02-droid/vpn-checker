import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../utils/constants.dart';
import '../utils/logger.dart';

class RawSource {
  final String name;
  final String text;
  const RawSource(this.name, this.text);
}

class GithubRateLimitException implements Exception {
  @override
  String toString() =>
      'محدودیت تعداد درخواست گیت‌هاب (rate limit). توکن گیت‌هاب را در تنظیمات وارد کنید یا بعداً تلاش کنید.';
}

class GithubService {
  GithubService({this.token});

  final String? token;
  final http.Client _client = http.Client();
  final List<String> warnings = [];
  bool _rateLimitWarned = false;
  bool _searchBlocked = false;

  Map<String, String> get _headers => {
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'vpn-config-checker',
        if (token != null && token!.trim().isNotEmpty)
          'Authorization': 'Bearer ${token!.trim()}',
      };

  Future<dynamic> _getJson(String url) async {
    final r = await _client
        .get(Uri.parse(url), headers: _headers)
        .timeout(AppConstants.httpTimeout);
    if (r.statusCode == 200) return jsonDecode(utf8.decode(r.bodyBytes));
    if (r.statusCode == 403 || r.statusCode == 429) {
      throw GithubRateLimitException();
    }
    throw Exception('HTTP ${r.statusCode}');
  }

  String _msg(Object e) {
    if (e is SocketException) return 'اتصال برقرار نشد';
    if (e is TimeoutException) return 'زمان انتظار تمام شد';
    return e.toString();
  }

  void _warn(String prefix, Object e) {
    if (e is GithubRateLimitException) {
      if (!_rateLimitWarned) {
        _rateLimitWarned = true;
        warnings.add(e.toString());
      }
      return;
    }
    warnings.add('$prefix: ${_msg(e)}');
  }

  Future<List<RawSource>> fetchAll({
    required void Function(String stage, double progress) onProgress,
    required bool Function() isCancelled,
  }) async {
    final sources = <RawSource>[];
    final repos = <String>{...AppConstants.repos};

    // ۱) جستجوی مخازن جدید
    final kws = AppConstants.searchKeywords;
    for (var i = 0; i < kws.length; i++) {
      if (isCancelled() || _searchBlocked) break;
      onProgress('جستجوی «${kws[i]}» در گیت‌هاب…', 0.2 * i / kws.length);
      try {
        repos.addAll(await _search(kws[i]));
      } catch (e) {
        if (e is GithubRateLimitException) _searchBlocked = true;
        _warn('جستجوی «${kws[i]}» ناموفق بود', e);
      }
      await Future.delayed(const Duration(milliseconds: 1200));
    }

    // ۲) دریافت فایل‌های هر مخزن (۳ مخزن همزمان)
    final list = repos.toList();
    var done = 0;
    for (var i = 0; i < list.length; i += 3) {
      if (isCancelled()) break;
      final chunk = list.skip(i).take(3).toList();
      final results = await Future.wait(chunk.map(_fetchRepo));
      for (final r in results) {
        sources.addAll(r);
      }
      done += chunk.length;
      onProgress('دریافت فایل‌ها ($done از ${list.length} مخزن)',
          0.2 + 0.8 * done / list.length);
    }
    return sources;
  }

  Future<List<String>> _search(String keyword) async {
    final url = '${AppConstants.githubApi}/search/repositories'
        '?q=${Uri.encodeQueryComponent(keyword)}&sort=updated&order=desc'
        '&per_page=${AppConstants.searchReposPerKeyword}';
    final data = await _getJson(url);
    final items = (data is Map ? data['items'] : null) as List? ?? [];
    return [
      for (final it in items)
        if (it is Map && it['fork'] != true && it['full_name'] != null)
          it['full_name'].toString()
    ];
  }

  Future<List<RawSource>> _fetchRepo(String repo) async {
    final out = <RawSource>[];
    try {
      final data = await _getJson(
          '${AppConstants.githubApi}/repos/$repo/git/trees/HEAD?recursive=1');
      final tree = (data is Map ? data['tree'] : null) as List? ?? [];
      final textFiles = <Map>[];
      final ovpnFiles = <Map>[];
      for (final e in tree) {
        if (e is! Map || e['type'] != 'blob') continue;
        final path = (e['path'] ?? '').toString();
        final size = (e['size'] is int) ? e['size'] as int : 0;
        if (size == 0 || size > AppConstants.maxFileBytes) continue;
        final low = path.toLowerCase();
        final base = low.split('/').last;
        if (base.startsWith('readme') ||
            base.startsWith('license') ||
            base.contains('package') ||
            base.contains('requirements') ||
            low.startsWith('.github/')) {
          continue;
        }
        if (low.endsWith('.ovpn')) {
          ovpnFiles.add(e);
        } else if (low.endsWith('.txt') ||
            low.endsWith('.json') ||
            low.endsWith('.conf')) {
          textFiles.add(e);
        }
      }
      textFiles.sort((a, b) => (b['size'] as int).compareTo(a['size'] as int));
      final picked = [
        ...textFiles.take(AppConstants.maxTextFilesPerRepo),
        ...ovpnFiles.take(AppConstants.maxOvpnFilesPerRepo),
      ];
      for (var i = 0; i < picked.length; i += 6) {
        final chunk = picked.skip(i).take(6);
        final res = await Future.wait(chunk.map((f) async {
          final path = f['path'].toString();
          try {
            final text = await _download(repo, path);
            return text == null ? null : RawSource('$repo/$path', text);
          } catch (e) {
            Log.e('دانلود $repo/$path', e);
            return null;
          }
        }));
        out.addAll(res.whereType<RawSource>());
      }
    } catch (e) {
      Log.e('مخزن $repo', e);
      _warn('مخزن $repo', e);
    }
    return out;
  }

  Future<String?> _download(String repo, String path) async {
    final encoded = path.split('/').map(Uri.encodeComponent).join('/');
    final r = await _client
        .get(Uri.parse('${AppConstants.rawHost}/$repo/HEAD/$encoded'),
            headers: {'User-Agent': 'vpn-config-checker'})
        .timeout(AppConstants.httpTimeout);
    if (r.statusCode != 200) return null;
    return utf8.decode(r.bodyBytes, allowMalformed: true);
  }
}
