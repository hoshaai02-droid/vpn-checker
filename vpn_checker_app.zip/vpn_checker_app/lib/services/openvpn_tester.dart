import 'dart:async';
import 'dart:io';
import 'dart:math';

import '../models/test_result.dart';
import '../models/vpn_config.dart';
import '../utils/constants.dart';

class OpenvpnTester {
  static Future<TestResult> test(VpnConfig c) async {
    return c.isUdp ? _udp(c) : _tcp(c);
  }

  static Future<TestResult> _tcp(VpnConfig c) async {
    final sw = Stopwatch()..start();
    try {
      final s = await Socket.connect(c.host, c.port,
          timeout: AppConstants.tcpTimeout);
      sw.stop();
      s.destroy();
      return TestResult.success(sw.elapsedMilliseconds);
    } catch (e) {
      return TestResult.fail(e.toString());
    }
  }

  /// UDP: یک بسته P_CONTROL_HARD_RESET_CLIENT_V2 می‌فرستیم؛ اگر سرور جواب داد → سالم.
  /// سرورهایی که tls-auth / tls-crypt دارند به این بسته جواب نمی‌دهند و ناموفق ثبت می‌شوند.
  static Future<TestResult> _udp(VpnConfig c) async {
    RawDatagramSocket? sock;
    StreamSubscription? sub;
    try {
      final addrs =
          await InternetAddress.lookup(c.host).timeout(AppConstants.tcpTimeout);
      if (addrs.isEmpty) return const TestResult.fail('DNS');
      final addr = addrs.first;
      sock = await RawDatagramSocket.bind(
          addr.type == InternetAddressType.IPv6
              ? InternetAddress.anyIPv6
              : InternetAddress.anyIPv4,
          0);
      final rnd = Random.secure();
      final sid = List<int>.generate(8, (_) => rnd.nextInt(256));
      final packet = <int>[0x38, ...sid, 0x00, 0, 0, 0, 0];
      final done = Completer<bool>();
      final sw = Stopwatch()..start();
      sub = sock.listen((ev) {
        if (ev == RawSocketEvent.read && !done.isCompleted) {
          final d = sock!.receive();
          if (d != null) done.complete(true);
        }
      });
      sock.send(packet, addr, c.port);
      final got = await done.future
          .timeout(AppConstants.tcpTimeout, onTimeout: () => false);
      sw.stop();
      return got
          ? TestResult.success(sw.elapsedMilliseconds)
          : const TestResult.fail('بدون پاسخ UDP');
    } catch (e) {
      return TestResult.fail(e.toString());
    } finally {
      await sub?.cancel();
      sock?.close();
    }
  }
}
