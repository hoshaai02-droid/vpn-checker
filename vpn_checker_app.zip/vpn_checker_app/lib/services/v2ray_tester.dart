import 'dart:async';

import 'package:flutter_v2ray/flutter_v2ray.dart';

import '../models/test_result.dart';
import '../models/vpn_config.dart';
import '../utils/constants.dart';
import '../utils/logger.dart';

/// تست واقعی V2Ray: هسته Xray کانفیگ را بالا می‌آورد، یک درخواست HTTP واقعی
/// به generate_204 از داخل همان تونل می‌فرستد و زمان پاسخ را برمی‌گرداند.
/// نیازی به مجوز VPN سیستم نیست.
class V2rayTester {
  final FlutterV2ray _v2ray = FlutterV2ray(onStatusChanged: (status) {});
  bool _ready = false;

  Future<bool> init() async {
    try {
      await _v2ray.initializeV2Ray();
      _ready = true;
    } catch (e) {
      Log.e('راه‌اندازی هسته Xray ناموفق بود', e);
      _ready = false;
    }
    return _ready;
  }

  Future<TestResult> test(VpnConfig c) async {
    if (!_ready) return const TestResult.fail('هسته آماده نیست');
    try {
      final parser = FlutterV2ray.parseFromURL(c.raw);
      final conf = parser.getFullConfiguration();
      final delay = await _v2ray
          .getServerDelay(config: conf, url: AppConstants.testUrl)
          .timeout(AppConstants.v2rayTimeout);
      if (delay > 0 && delay < 10000) return TestResult.success(delay);
      return const TestResult.fail('پاسخی دریافت نشد');
    } on TimeoutException {
      return const TestResult.fail('Timeout');
    } catch (e) {
      return TestResult.fail(e.toString());
    }
  }
}
