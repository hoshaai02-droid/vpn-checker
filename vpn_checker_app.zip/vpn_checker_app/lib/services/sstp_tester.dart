import 'dart:async';
import 'dart:io';

import '../models/test_result.dart';
import '../models/vpn_config.dart';
import '../utils/constants.dart';

/// SSTP روی TLS (معمولاً پورت 443) کار می‌کند؛ پس اتصال TCP + دست‌دادن TLS را تست می‌کنیم.
/// گواهی‌های self-signed عمداً پذیرفته می‌شوند چون در سرورهای SSTP رایگان رایج‌اند.
class SstpTester {
  static Future<TestResult> test(VpnConfig c) async {
    final sw = Stopwatch()..start();
    try {
      final s = await SecureSocket.connect(
        c.host,
        c.port,
        onBadCertificate: (_) => true,
        timeout: AppConstants.tcpTimeout,
      ).timeout(AppConstants.tcpTimeout + const Duration(seconds: 2));
      sw.stop();
      s.destroy();
      return TestResult.success(sw.elapsedMilliseconds);
    } catch (e) {
      return TestResult.fail(e.toString());
    }
  }
}
