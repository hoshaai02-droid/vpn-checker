import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/vpn_config.dart';
import '../utils/logger.dart';

/// ذخیره کانفیگ‌های سالم در SQLite (فایل configs.db)
class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  Database? _db;

  Future<Database> get _database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'configs.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, v) async {
        await db.execute('''
CREATE TABLE configs(
  id TEXT PRIMARY KEY,
  protocol TEXT NOT NULL,
  raw TEXT NOT NULL,
  host TEXT NOT NULL,
  port INTEGER NOT NULL,
  remark TEXT,
  country TEXT,
  is_udp INTEGER DEFAULT 0,
  latency INTEGER,
  tested_at INTEGER
)''');
      },
    );
  }

  Future<List<VpnConfig>> activeConfigs() async {
    try {
      final db = await _database;
      final rows = await db.query('configs', orderBy: 'latency ASC');
      return rows.map(VpnConfig.fromMap).toList();
    } catch (e) {
      Log.e('خواندن دیتابیس', e);
      return [];
    }
  }

  Future<void> replaceAll(List<VpnConfig> list) async {
    final db = await _database;
    await db.transaction((txn) async {
      await txn.delete('configs');
      final b = txn.batch();
      for (final c in list) {
        b.insert('configs', c.toMap(),
            conflictAlgorithm: ConflictAlgorithm.replace);
      }
      await b.commit(noResult: true);
    });
  }

  Future<void> clear() async {
    try {
      final db = await _database;
      await db.delete('configs');
    } catch (e) {
      Log.e('پاک کردن دیتابیس', e);
    }
  }
}
