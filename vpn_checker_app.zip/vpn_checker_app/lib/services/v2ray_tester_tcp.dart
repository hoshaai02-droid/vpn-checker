import 'dart:io';

import '../models/test_result.dart';
import '../models/vpn_config.dart';
import '../utils/constants.dart';

/// نسخه ساده: فقط اتصال TCP به host:port (نشان‌دهنده باز بودن پورت است، نه سالم بودن کانفیگ).
class V2rayTester {
  /// provider این را برای پیام خطا می‌خواند؛ در این نسخه همیشه null است.
  String? lastInitError;

  Future<bool> init() async => true;

  Future<TestResult> test(VpnConfig c) async {
    final sw = Stopwatch()..start();
    try {
      final socket = await Socket.connect(
        c.host,
        c.port,
        timeout: AppConstants.tcpTimeout,
      );
      sw.stop();
      socket.destroy();
      return TestResult.success(sw.elapsedMilliseconds);
    } catch (e) {
      return TestResult.fail(e.toString());
    }
  }

  /// provider در پایان تست صدا می‌زند؛ چیزی برای بستن نیست.
  Future<void> dispose() async {}
}
