/// اجرای همزمان کارها با سقف مشخص (مثلاً ۱۰ تست هم‌زمان).
Future<void> runPool<T>(
  List<T> items,
  int concurrency,
  Future<void> Function(T item) job, {
  bool Function()? isCancelled,
}) async {
  var next = 0;
  Future<void> worker() async {
    while (true) {
      if (isCancelled?.call() ?? false) return;
      if (next >= items.length) return;
      final item = items[next++];
      try {
        await job(item);
      } catch (_) {
        // خطای یک کانفیگ نباید کل کار را متوقف کند
      }
    }
  }

  final n = concurrency < 1 ? 1 : concurrency;
  await Future.wait(List.generate(n, (_) => worker()));
}
