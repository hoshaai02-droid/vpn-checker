import 'dart:convert';

import '../models/vpn_config.dart';

/// تبدیل متن فایل‌ها (txt/json/conf/ovpn) به لیست کانفیگ.
class ConfigParser {
  static final RegExp _linkRe = RegExp(
      r'''\b(?:vmess|vless|trojan|ss)://[^\s"'<>\\]+''',
      caseSensitive: false);
  static final RegExp _sstpLinkRe =
      RegExp(r'''\bsstp://[^\s"'<>\\]+''', caseSensitive: false);
  static final RegExp _remoteRe = RegExp(
      r'^\s*remote\s+(\S+)\s+(\d{1,5})(?:\s+(tcp|udp)\S*)?',
      multiLine: true,
      caseSensitive: false);
  static final RegExp _protoRe = RegExp(r'^\s*proto\s+(tcp|udp)',
      multiLine: true, caseSensitive: false);
  static final RegExp _hostPortRe = RegExp(
      r'^((?:\d{1,3}\.){3}\d{1,3}|[A-Za-z0-9][A-Za-z0-9.\-]*\.[A-Za-z]{2,})(?::(\d{1,5}))?$');

  static const Set<String> _countryCodes = {
    'US', 'DE', 'NL', 'FR', 'GB', 'UK', 'JP', 'SG', 'HK', 'TW', 'KR', 'CA',
    'AU', 'RU', 'TR', 'IR', 'IN', 'SE', 'FI', 'CH', 'PL', 'UA', 'AE', 'BR',
    'IT', 'ES', 'NO', 'RO', 'AT', 'CZ', 'LT', 'LV', 'BG', 'ID', 'TH', 'VN',
    'MY', 'IL', 'AR', 'ZA', 'MX', 'CL', 'IE', 'DK', 'BE', 'PT', 'HU', 'KZ',
  };

  static List<VpnConfig> parseText(String text, {String fileName = ''}) {
    final out = <VpnConfig>[];
    final lowerName = fileName.toLowerCase();

    if (lowerName.endsWith('.ovpn') || _looksLikeOvpn(text)) {
      final c = parseOvpn(text, fileName);
      if (c != null) out.add(c);
      return out;
    }

    var body = text;
    var links = _extractLinks(body);
    if (links.isEmpty) {
      final decoded = _b64(text);
      if (decoded != null && decoded.isNotEmpty) {
        body = decoded;
        links = _extractLinks(body);
      }
    }
    for (final l in links) {
      final c = parseLink(l);
      if (c != null) out.add(c);
    }

    for (final m in _sstpLinkRe.allMatches(body)) {
      final c = parseLink(m.group(0)!);
      if (c != null) out.add(c);
    }

    if (lowerName.contains('sstp')) {
      out.addAll(_parseSstpLines(body));
    }
    return out;
  }

  static bool _looksLikeOvpn(String text) {
    if (!RegExp(r'^\s*remote\s+\S+\s+\d+', multiLine: true).hasMatch(text)) {
      return false;
    }
    return text.contains('<ca>') ||
        RegExp(r'^\s*(client|dev\s+tun)', multiLine: true).hasMatch(text);
  }

  static List<String> _extractLinks(String t) =>
      _linkRe.allMatches(t).map((m) => m.group(0)!).toList();

  static VpnConfig? parseLink(String link) {
    try {
      final idx = link.indexOf('://');
      if (idx < 0) return null;
      final scheme = link.substring(0, idx).toLowerCase();
      final fixed = scheme + link.substring(idx);
      switch (scheme) {
        case 'vmess':
          return _vmess(fixed);
        case 'vless':
          return _uriBased(fixed, VpnProtocol.vless);
        case 'trojan':
          return _uriBased(fixed, VpnProtocol.trojan);
        case 'ss':
          return _ss(fixed);
        case 'sstp':
          return _sstpLink(fixed);
      }
    } catch (_) {}
    return null;
  }

  static VpnConfig? _vmess(String link) {
    final body = link.substring(8).split('#').first;
    final js = _b64(body);
    if (js == null) return null;
    final m = jsonDecode(js);
    if (m is! Map) return null;
    final host = (m['add'] ?? '').toString();
    final port = int.tryParse((m['port'] ?? '').toString()) ?? 0;
    final remark = (m['ps'] ?? '').toString();
    return _make(VpnProtocol.vmess, link, link, host, port, remark);
  }

  static VpnConfig? _uriBased(String link, VpnProtocol p) {
    final u = Uri.parse(link);
    final remark = _safeDecode(u.fragment);
    final key = link.split('#').first;
    return _make(p, link, key, u.host, u.hasPort ? u.port : 0, remark);
  }

  static VpnConfig? _ss(String link) {
    var rest = link.substring(5);
    var remark = '';
    final h = rest.indexOf('#');
    if (h >= 0) {
      remark = _safeDecode(rest.substring(h + 1));
      rest = rest.substring(0, h);
    }
    final key = rest;
    final q = rest.indexOf('?');
    if (q >= 0) rest = rest.substring(0, q);
    rest = rest.replaceAll(RegExp(r'/+$'), '');

    String hostPort;
    if (rest.contains('@')) {
      hostPort = rest.substring(rest.lastIndexOf('@') + 1);
    } else {
      final d = _b64(rest);
      if (d == null || !d.contains('@')) return null;
      hostPort = d.substring(d.lastIndexOf('@') + 1);
    }
    final i = hostPort.lastIndexOf(':');
    if (i < 0) return null;
    final host =
        hostPort.substring(0, i).replaceAll('[', '').replaceAll(']', '').trim();
    final port =
        int.tryParse(hostPort.substring(i + 1).replaceAll('/', '').trim()) ?? 0;
    return _make(VpnProtocol.ss, link, 'ss|$key', host, port, remark);
  }

  static VpnConfig? _sstpLink(String link) {
    final u = Uri.parse(link);
    final port = u.hasPort && u.port > 0 ? u.port : 443;
    final remark = _safeDecode(u.fragment);
    return _make(VpnProtocol.sstp, link, 'sstp|${u.host}|$port', u.host, port,
        remark.isEmpty ? u.host : remark);
  }

  static List<VpnConfig> _parseSstpLines(String text) {
    final out = <VpnConfig>[];
    for (final line in text.split('\n')) {
      for (final token in line.trim().split(RegExp(r'[,\s;]+'))) {
        final m = _hostPortRe.firstMatch(token);
        if (m == null) continue;
        final host = m.group(1)!;
        final port = int.tryParse(m.group(2) ?? '') ?? 443;
        final c = _make(VpnProtocol.sstp, 'sstp://$host:$port',
            'sstp|$host|$port', host, port, host);
        if (c != null) out.add(c);
        break;
      }
    }
    return out;
  }

  static VpnConfig? parseOvpn(String text, String fileName) {
    final m = _remoteRe.firstMatch(text);
    if (m == null) return null;
    final host = m.group(1)!;
    final port = int.tryParse(m.group(2)!) ?? 1194;
    var proto = (m.group(3) ?? '').toLowerCase();
    if (proto.isEmpty) {
      proto = _protoRe.firstMatch(text)?.group(1)?.toLowerCase() ?? 'udp';
    }
    if (port < 1 || port > 65535 || host.isEmpty) return null;
    var name = fileName.split('/').last;
    final dot = name.lastIndexOf('.');
    if (dot > 0) name = name.substring(0, dot);
    final remark = name.isEmpty ? host : name;
    return VpnConfig(
      id: _hash('ovpn|$host|$port|$proto'),
      protocol: VpnProtocol.openvpn,
      raw: text,
      host: host,
      port: port,
      remark: remark,
      country: detectCountry(remark),
      isUdp: proto == 'udp',
    );
  }

  static VpnConfig? _make(VpnProtocol p, String raw, String key, String host,
      int port, String remark) {
    if (host.isEmpty || port < 1 || port > 65535) return null;
    return VpnConfig(
      id: _hash('${p.name}|$key'),
      protocol: p,
      raw: raw,
      host: host,
      port: port,
      remark: remark,
      country: detectCountry(remark),
    );
  }

  /// تشخیص کشور از پرچم ایموجی یا کد دوحرفی داخل اسم کانفیگ
  static String detectCountry(String remark) {
    final r = remark.runes.toList();
    for (var i = 0; i < r.length - 1; i++) {
      if (r[i] >= 0x1F1E6 &&
          r[i] <= 0x1F1FF &&
          r[i + 1] >= 0x1F1E6 &&
          r[i + 1] <= 0x1F1FF) {
        return String.fromCharCodes(
            [r[i] - 0x1F1E6 + 65, r[i + 1] - 0x1F1E6 + 65]);
      }
    }
    for (final m in RegExp(r'\b[A-Z]{2}\b').allMatches(remark)) {
      final c = m.group(0)!;
      if (_countryCodes.contains(c)) return c == 'UK' ? 'GB' : c;
    }
    return '';
  }

  static String flag(String code) {
    if (code.length != 2) return '🌐';
    return String.fromCharCodes(
        code.toUpperCase().codeUnits.map((c) => c - 65 + 0x1F1E6));
  }

  static String? _b64(String s) {
    try {
      var t = s.replaceAll(RegExp(r'\s'), '').replaceAll('-', '+').replaceAll('_', '/');
      if (t.isEmpty) return null;
      final pad = (4 - t.length % 4) % 4;
      t = t + ('=' * pad);
      return utf8.decode(base64.decode(t), allowMalformed: true);
    } catch (_) {
      return null;
    }
  }

  static String _safeDecode(String s) {
    try {
      return Uri.decodeComponent(s);
    } catch (_) {
      return s;
    }
  }

  static String _fnv(String s, int seed) {
    var h = seed;
    for (final b in utf8.encode(s)) {
      h ^= b;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return h.toRadixString(16).padLeft(8, '0');
  }

  static String _hash(String s) => _fnv(s, 0x811c9dc5) + _fnv('#$s', 0x1234abcd);
}
