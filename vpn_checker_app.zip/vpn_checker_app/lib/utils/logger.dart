import 'package:flutter/foundation.dart';

/// لاگ‌گیری ساده؛ آخرین ۳۰۰ خط در حافظه نگه داشته می‌شود.
class Log {
  static final List<String> _buffer = [];

  static void i(String message) => _add('I', message);

  static void e(String message, [Object? error]) =>
      _add('E', error == null ? message : '$message | $error');

  static void _add(String level, String message) {
    final line = '[$level] $message';
    if (_buffer.length >= 300) _buffer.removeAt(0);
    _buffer.add(line);
    debugPrint(line);
  }

  static List<String> get lines => List.unmodifiable(_buffer);
}
