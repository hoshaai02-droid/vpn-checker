import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/vpn_config.dart';
import '../utils/parser.dart';

class ConfigCard extends StatelessWidget {
  final VpnConfig config;
  const ConfigCard({super.key, required this.config});

  String _fmt(DateTime? t) {
    if (t == null) return '-';
    String two(int n) => n.toString().padLeft(2, '0');
    return '${t.year}/${two(t.month)}/${two(t.day)}  ${two(t.hour)}:${two(t.minute)}';
  }

  IconData get _icon {
    switch (config.protocol.group) {
      case 'openvpn':
        return Icons.vpn_key;
      case 'sstp':
        return Icons.lock;
      default:
        return Icons.bolt;
    }
  }

  Future<void> _copy(BuildContext context) async {
    await Clipboard.setData(ClipboardData(text: config.raw));
    if (context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('کانفیگ کپی شد')));
    }
  }

  Future<void> _share() async {
    try {
      await Share.share(config.raw, subject: config.remark);
    } catch (_) {}
  }

  Future<void> _connect(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    if (config.protocol.isV2ray) {
      try {
        final ok = await launchUrl(Uri.parse(config.raw),
            mode: LaunchMode.externalApplication);
        if (ok) return;
      } catch (_) {}
      await Clipboard.setData(ClipboardData(text: config.raw));
      messenger.showSnackBar(const SnackBar(
          content: Text(
              'اپ v2rayNG پیدا نشد. کانفیگ کپی شد؛ آن را در اپ V2Ray خود وارد کنید.')));
    } else {
      await _share();
      messenger.showSnackBar(const SnackBar(
          content: Text('کانفیگ را به اپ OpenVPN Connect (یا اپ مناسب) بفرستید.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final title = config.remark.isEmpty ? config.host : config.remark;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                    backgroundColor: cs.primaryContainer,
                    child: Icon(_icon, color: cs.onPrimaryContainer)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(
                        '${config.protocol.label}${config.isUdp ? ' (UDP)' : ''} • ${config.host}:${config.port}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall,
                        textDirection: TextDirection.ltr,
                      ),
                    ],
                  ),
                ),
                Text(ConfigParser.flag(config.country),
                    style: const TextStyle(fontSize: 24)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.speed, size: 18),
                const SizedBox(width: 4),
                Text('${config.latencyMs} ms'),
                const SizedBox(width: 16),
                const Icon(Icons.schedule, size: 18),
                const SizedBox(width: 4),
                Expanded(
                    child: Text(_fmt(config.testedAt),
                        style: Theme.of(context).textTheme.bodySmall)),
              ],
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                TextButton.icon(
                    onPressed: () => _copy(context),
                    icon: const Icon(Icons.copy, size: 18),
                    label: const Text('کپی')),
                TextButton.icon(
                    onPressed: _share,
                    icon: const Icon(Icons.share, size: 18),
                    label: const Text('اشتراک‌گذاری')),
                FilledButton.tonalIcon(
                    onPressed: () => _connect(context),
                    icon: const Icon(Icons.open_in_new, size: 18),
                    label: const Text('اتصال')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
