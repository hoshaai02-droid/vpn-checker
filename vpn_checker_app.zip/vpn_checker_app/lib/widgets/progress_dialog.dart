import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/configs_provider.dart';

/// پنجره پیشرفت؛ وقتی بروزرسانی تمام شد خودش بسته می‌شود.
class ProgressDialog extends StatefulWidget {
  const ProgressDialog({super.key});

  @override
  State<ProgressDialog> createState() => _ProgressDialogState();
}

class _ProgressDialogState extends State<ProgressDialog> {
  bool _closed = false;

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ConfigsProvider>();
    if (!p.running && !_closed) {
      _closed = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
      });
    }
    final percent = (p.progress * 100).clamp(0, 100).toStringAsFixed(0);
    return AlertDialog(
      title: const Text('در حال بروزرسانی'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          LinearProgressIndicator(value: p.progress <= 0 ? null : p.progress),
          const SizedBox(height: 12),
          Text('$percent٪'),
          const SizedBox(height: 6),
          Text(p.stage),
          const SizedBox(height: 6),
          Text('سالم: ${p.okCount}   ناموفق: ${p.failed}'),
        ],
      ),
      actions: [
        TextButton(onPressed: p.cancel, child: const Text('لغو')),
      ],
    );
  }
}
