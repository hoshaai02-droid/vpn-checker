import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';

import '../utils/constants.dart';
import '../utils/logger.dart';

const FlutterSecureStorage appSecureStorage =
    FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));
const String githubTokenKey = 'github_token';

class SettingsProvider extends ChangeNotifier {
  String token = '';
  int intervalHours = 0; // 0 = دستی

  Future<void> load() async {
    try {
      token = await appSecureStorage.read(key: githubTokenKey) ?? '';
    } catch (e) {
      Log.e('خواندن توکن', e);
    }
    try {
      final p = await SharedPreferences.getInstance();
      intervalHours = p.getInt('interval_hours') ?? 0;
    } catch (e) {
      Log.e('خواندن تنظیمات', e);
    }
    notifyListeners();
  }

  Future<void> saveToken(String value) async {
    token = value.trim();
    try {
      if (token.isEmpty) {
        await appSecureStorage.delete(key: githubTokenKey);
      } else {
        await appSecureStorage.write(key: githubTokenKey, value: token);
      }
    } catch (e) {
      Log.e('ذخیره توکن', e);
    }
    notifyListeners();
  }

  Future<void> setInterval(int hours) async {
    intervalHours = hours;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('interval_hours', hours);
      await Workmanager().cancelByUniqueName(AppConstants.autoTaskName);
      if (hours > 0) {
        await Workmanager().registerPeriodicTask(
          AppConstants.autoTaskName,
          AppConstants.autoTaskName,
          frequency: Duration(hours: hours),
          existingWorkPolicy: ExistingWorkPolicy.replace,
          constraints: Constraints(networkType: NetworkType.connected),
        );
      }
    } catch (e) {
      Log.e('زمان‌بندی بروزرسانی خودکار', e);
    }
    notifyListeners();
  }
}
