class TestResult {
  final bool ok;
  final int latencyMs;
  final String? error;

  const TestResult.success(this.latencyMs)
      : ok = true,
        error = null;

  const TestResult.fail([this.error])
      : ok = false,
        latencyMs = -1;
}
