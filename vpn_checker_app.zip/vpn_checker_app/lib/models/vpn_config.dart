enum VpnProtocol { vmess, vless, trojan, ss, openvpn, sstp }

extension VpnProtocolX on VpnProtocol {
  bool get isV2ray =>
      this == VpnProtocol.vmess ||
      this == VpnProtocol.vless ||
      this == VpnProtocol.trojan ||
      this == VpnProtocol.ss;

  /// گروه نمایش در فیلترها: v2ray / openvpn / sstp
  String get group =>
      isV2ray ? 'v2ray' : (this == VpnProtocol.openvpn ? 'openvpn' : 'sstp');

  String get label {
    switch (this) {
      case VpnProtocol.vmess:
        return 'VMess';
      case VpnProtocol.vless:
        return 'VLESS';
      case VpnProtocol.trojan:
        return 'Trojan';
      case VpnProtocol.ss:
        return 'Shadowsocks';
      case VpnProtocol.openvpn:
        return 'OpenVPN';
      case VpnProtocol.sstp:
        return 'SSTP';
    }
  }
}

class VpnConfig {
  final String id;
  final VpnProtocol protocol;
  final String raw;
  final String host;
  final int port;
  final String remark;
  final String country; // کد دوحرفی مثل US یا خالی
  final bool isUdp;
  int latencyMs;
  DateTime? testedAt;
  bool ok;

  VpnConfig({
    required this.id,
    required this.protocol,
    required this.raw,
    required this.host,
    required this.port,
    this.remark = '',
    this.country = '',
    this.isUdp = false,
    this.latencyMs = -1,
    this.testedAt,
    this.ok = false,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'protocol': protocol.name,
        'raw': raw,
        'host': host,
        'port': port,
        'remark': remark,
        'country': country,
        'is_udp': isUdp ? 1 : 0,
        'latency': latencyMs,
        'tested_at': testedAt?.millisecondsSinceEpoch,
      };

  factory VpnConfig.fromMap(Map<String, Object?> m) => VpnConfig(
        id: m['id'] as String,
        protocol: VpnProtocol.values.byName(m['protocol'] as String),
        raw: m['raw'] as String,
        host: m['host'] as String,
        port: m['port'] as int,
        remark: (m['remark'] as String?) ?? '',
        country: (m['country'] as String?) ?? '',
        isUdp: (m['is_udp'] as int? ?? 0) == 1,
        latencyMs: (m['latency'] as int?) ?? -1,
        testedAt: m['tested_at'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(m['tested_at'] as int),
        ok: true,
      );
}
