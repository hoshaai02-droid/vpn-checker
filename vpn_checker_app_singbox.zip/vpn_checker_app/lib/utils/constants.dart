class AppConstants {
  static const String appName = 'VPN Config Checker';
  static const String githubApi = 'https://api.github.com';
  static const String rawHost = 'https://raw.githubusercontent.com';

  /// آدرسی که کانفیگ‌های V2Ray برای اثبات «واقعاً کار می‌کنه» به آن وصل می‌شوند
  static const String testUrl = 'https://www.google.com/generate_204';

  /// بودجه زمانی هر کانفیگ V2Ray (شامل تلاش مجدد داخلی) برای درخواست generate_204
  static const Duration v2rayTimeout = Duration(seconds: 15);
  static const Duration tcpTimeout = Duration(seconds: 10);
  static const Duration httpTimeout = Duration(seconds: 25);

  /// تعداد کانفیگ در هر «دسته» Sing-box (یک هسته، ۵ inbound/outbound هم‌زمان)
  static const int v2rayConcurrency = 5;
  static const int lightConcurrency = 40;

  /// سقف تعداد کانفیگ برای تست در هر بروزرسانی (برای جلوگیری از طولانی شدن)
  static const int maxV2rayToTest = 400;
  static const int maxOtherToTest = 300;

  static const int maxTextFilesPerRepo = 8;
  static const int maxOvpnFilesPerRepo = 25;
  static const int maxFileBytes = 3 * 1024 * 1024;

  static const int searchReposPerKeyword = 3;

  static const List<String> repos = [
    'barry-far/V2ray-Configs',
    'Epodonios/v2ray-configs',
    'mahdibland/ShadowsocksAggregator',
    'freefq/free',
    'MhdiTaheri/V2rayCollector',
    'vpei/Free-Node-Merge',
  ];

  static const List<String> searchKeywords = [
    'v2ray configs',
    'vmess',
    'vless',
    'openvpn config',
    'sstp config',
  ];

  static const String autoTaskName = 'vpn_checker_auto_update';
}
