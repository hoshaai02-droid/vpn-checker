import 'dart:convert';

import '../models/vpn_config.dart';

/// وقتی کانفیگ قابل تبدیل به Sing-box نیست (مثلاً ترنسپورت xhttp یا kcp).
class ConfigConvertException implements Exception {
  final String message;
  const ConfigConvertException(this.message);
  @override
  String toString() => message;
}

/// تبدیل لینک vmess / vless / trojan / ss به یک «outbound» معتبر Sing-box
/// و ساخت کانفیگ کامل (چند outbound + برای هرکدام یک inbound HTTP لوکال).
class SingboxConverter {
  // ───────────────────────── کانفیگ کامل ─────────────────────────

  /// [entries]: هر آیتم یک outbound با tag یکتا و پورت لوکال اختصاصی خودش.
  /// مسیر: inbound شماره i  →  فقط outbound شماره i  (کانفیگ‌ها با هم قاطی نمی‌شوند)
  static String buildBatchConfig(
    List<({String tag, Map<String, dynamic> outbound, int port})> entries,
  ) {
    final inbounds = <Map<String, dynamic>>[];
    final rules = <Map<String, dynamic>>[];
    final outbounds = <Map<String, dynamic>>[];

    for (final e in entries) {
      final inTag = 'in-${e.tag}';
      inbounds.add({
        'type': 'http',
        'tag': inTag,
        'listen': '127.0.0.1',
        'listen_port': e.port,
      });
      outbounds.add(e.outbound);
      rules.add({
        'inbound': [inTag],
        'action': 'route',
        'outbound': e.tag,
      });
    }

    final cfg = <String, dynamic>{
      'log': {'level': 'warn', 'timestamp': true},
      // فرمت جدید DNS (sing-box >= 1.12). فقط برای resolve کردن آدرس خود سرورها.
      'dns': {
        'servers': [
          {'type': 'local', 'tag': 'dns-local'},
        ],
      },
      'inbounds': inbounds,
      'outbounds': outbounds,
      'route': {
        'rules': rules,
        'default_domain_resolver': 'dns-local',
      },
    };
    return jsonEncode(cfg);
  }

  // ───────────────────────── تبدیل یک لینک ─────────────────────────

  static Map<String, dynamic> outbound(VpnConfig c, String tag) {
    try {
      switch (c.protocol) {
        case VpnProtocol.vmess:
          return _vmess(c.raw, tag);
        case VpnProtocol.vless:
          return _vless(c.raw, tag);
        case VpnProtocol.trojan:
          return _trojan(c.raw, tag);
        case VpnProtocol.ss:
          return _shadowsocks(c.raw, tag);
        default:
          throw const ConfigConvertException('پروتکل V2Ray نیست');
      }
    } on ConfigConvertException {
      rethrow;
    } catch (e) {
      throw ConfigConvertException('خطا در تحلیل لینک: $e');
    }
  }

  // ───────────────────────── VMess ─────────────────────────

  static Map<String, dynamic> _vmess(String link, String tag) {
    final body = link.substring(link.indexOf('://') + 3).split('#').first;
    final js = _b64(body);
    if (js == null) throw const ConfigConvertException('base64 نامعتبر در vmess');
    final m = jsonDecode(js);
    if (m is! Map) throw const ConfigConvertException('JSON نامعتبر در vmess');

    String s(String k) => (m[k] ?? '').toString().trim();

    final host = s('add');
    final port = int.tryParse(s('port')) ?? 0;
    final uuid = s('id');
    if (host.isEmpty || port < 1 || port > 65535 || uuid.isEmpty) {
      throw const ConfigConvertException('آدرس/پورت/UUID ناقص');
    }

    final net = s('net').isEmpty ? 'tcp' : s('net').toLowerCase();
    final out = <String, dynamic>{
      'type': 'vmess',
      'tag': tag,
      'server': host,
      'server_port': port,
      'uuid': uuid,
      'security': s('scy').isEmpty ? 'auto' : s('scy'),
      'alter_id': int.tryParse(s('aid')) ?? 0,
    };

    final tlsOn = s('tls').toLowerCase() == 'tls';
    if (tlsOn) {
      out['tls'] = _tls(
        sni: s('sni').isNotEmpty ? s('sni') : s('host'),
        alpn: s('alpn'),
        fp: s('fp'),
        insecure: _truthy(s('allowInsecure')) || _truthy(s('insecure')),
      );
    }

    final transport = _transport(
      net: net,
      headerType: s('type'),
      host: s('host'),
      path: s('path'),
      serviceName: s('path'), // در vmess نام سرویس gRPC داخل path می‌آید
      tlsOn: tlsOn,
    );
    if (transport != null) out['transport'] = transport;
    return out;
  }

  // ───────────────────────── VLESS ─────────────────────────

  static Map<String, dynamic> _vless(String link, String tag) {
    final u = _uri(link);
    final q = u.queryParameters;
    final uuid = Uri.decodeComponent(u.userInfo);
    if (u.host.isEmpty || !u.hasPort || uuid.isEmpty) {
      throw const ConfigConvertException('آدرس/پورت/UUID ناقص');
    }

    final enc = (q['encryption'] ?? 'none').toLowerCase();
    if (enc != 'none' && enc.isNotEmpty) {
      throw ConfigConvertException('vless encryption=$enc پشتیبانی نمی‌شود');
    }

    final out = <String, dynamic>{
      'type': 'vless',
      'tag': tag,
      'server': u.host,
      'server_port': u.port,
      'uuid': uuid,
    };

    final security = (q['security'] ?? 'none').toLowerCase();
    final flow = q['flow'] ?? '';
    final tlsOn = security == 'tls' || security == 'reality';

    if (security == 'reality') {
      final pbk = q['pbk'] ?? '';
      if (pbk.isEmpty) {
        throw const ConfigConvertException('Reality بدون public key (pbk)');
      }
      out['tls'] = _tls(
        sni: q['sni'] ?? '',
        alpn: q['alpn'] ?? '',
        fp: (q['fp'] ?? '').isEmpty ? 'chrome' : q['fp']!, // Reality به uTLS نیاز دارد
        insecure: false,
        reality: {
          'enabled': true,
          'public_key': pbk,
          'short_id': q['sid'] ?? '',
        },
      );
    } else if (security == 'tls') {
      out['tls'] = _tls(
        sni: (q['sni'] ?? '').isNotEmpty ? q['sni']! : (q['host'] ?? ''),
        alpn: q['alpn'] ?? '',
        fp: q['fp'] ?? '',
        insecure: _truthy(q['allowInsecure']) || _truthy(q['insecure']),
      );
    } else if (security != 'none' && security.isNotEmpty) {
      throw ConfigConvertException('security=$security پشتیبانی نمی‌شود');
    }

    if (flow.isNotEmpty && tlsOn) out['flow'] = flow;

    final transport = _transport(
      net: (q['type'] ?? 'tcp').toLowerCase(),
      headerType: q['headerType'] ?? '',
      host: q['host'] ?? '',
      path: q['path'] ?? '',
      serviceName: (q['serviceName'] ?? '').isNotEmpty
          ? q['serviceName']!
          : (q['path'] ?? ''),
      tlsOn: tlsOn,
    );
    if (transport != null) out['transport'] = transport;
    return out;
  }

  // ───────────────────────── Trojan ─────────────────────────

  static Map<String, dynamic> _trojan(String link, String tag) {
    final u = _uri(link);
    final q = u.queryParameters;
    final password = Uri.decodeComponent(u.userInfo);
    if (u.host.isEmpty || !u.hasPort || password.isEmpty) {
      throw const ConfigConvertException('آدرس/پورت/رمز ناقص');
    }

    final out = <String, dynamic>{
      'type': 'trojan',
      'tag': tag,
      'server': u.host,
      'server_port': u.port,
      'password': password,
    };

    final security = (q['security'] ?? 'tls').toLowerCase();
    final tlsOn = security != 'none';
    if (tlsOn) {
      out['tls'] = _tls(
        sni: (q['sni'] ?? '').isNotEmpty
            ? q['sni']!
            : ((q['peer'] ?? '').isNotEmpty ? q['peer']! : (q['host'] ?? '')),
        alpn: q['alpn'] ?? '',
        fp: q['fp'] ?? '',
        insecure: _truthy(q['allowInsecure']) || _truthy(q['insecure']),
      );
    }

    final transport = _transport(
      net: (q['type'] ?? 'tcp').toLowerCase(),
      headerType: q['headerType'] ?? '',
      host: q['host'] ?? '',
      path: q['path'] ?? '',
      serviceName: (q['serviceName'] ?? '').isNotEmpty
          ? q['serviceName']!
          : (q['path'] ?? ''),
      tlsOn: tlsOn,
    );
    if (transport != null) out['transport'] = transport;
    return out;
  }

  // ───────────────────────── Shadowsocks ─────────────────────────

  static Map<String, dynamic> _shadowsocks(String link, String tag) {
    var rest = link.substring(link.indexOf('://') + 3);
    final h = rest.indexOf('#');
    if (h >= 0) rest = rest.substring(0, h);

    var query = '';
    final qi = rest.indexOf('?');
    if (qi >= 0) {
      query = rest.substring(qi + 1);
      rest = rest.substring(0, qi);
    }
    rest = rest.replaceAll(RegExp(r'/+$'), '');

    String userInfo;
    String hostPort;
    if (rest.contains('@')) {
      // SIP002:  base64(method:pass)@host:port   یا   method:pass@host:port
      final at = rest.lastIndexOf('@');
      userInfo = rest.substring(0, at);
      hostPort = rest.substring(at + 1);
      if (!userInfo.contains(':')) {
        final d = _b64(Uri.decodeComponent(userInfo));
        if (d == null) throw const ConfigConvertException('userinfo ss نامعتبر');
        userInfo = d;
      } else {
        userInfo = Uri.decodeComponent(userInfo);
      }
    } else {
      // قدیمی: base64(method:pass@host:port)
      final d = _b64(rest);
      if (d == null || !d.contains('@')) {
        throw const ConfigConvertException('لینک ss نامعتبر');
      }
      final at = d.lastIndexOf('@');
      userInfo = d.substring(0, at);
      hostPort = d.substring(at + 1);
    }

    final colon = userInfo.indexOf(':');
    if (colon < 1) throw const ConfigConvertException('method/password ناقص');
    final method = userInfo.substring(0, colon);
    final password = userInfo.substring(colon + 1);

    final pi = hostPort.lastIndexOf(':');
    if (pi < 0) throw const ConfigConvertException('پورت ss ناقص');
    final host = hostPort
        .substring(0, pi)
        .replaceAll('[', '')
        .replaceAll(']', '')
        .trim();
    final port = int.tryParse(hostPort.substring(pi + 1).trim()) ?? 0;
    if (host.isEmpty || port < 1 || port > 65535) {
      throw const ConfigConvertException('آدرس/پورت ss نامعتبر');
    }

    final out = <String, dynamic>{
      'type': 'shadowsocks',
      'tag': tag,
      'server': host,
      'server_port': port,
      'method': method,
      'password': password,
    };

    if (query.isNotEmpty) {
      final params = Uri.splitQueryString(query);
      final plugin = params['plugin'];
      if (plugin != null && plugin.isNotEmpty) {
        final semi = plugin.indexOf(';');
        var name = semi < 0 ? plugin : plugin.substring(0, semi);
        final opts = semi < 0 ? '' : plugin.substring(semi + 1);
        if (name == 'simple-obfs') name = 'obfs-local';
        if (name != 'obfs-local' && name != 'v2ray-plugin') {
          throw ConfigConvertException('پلاگین ss «$name» پشتیبانی نمی‌شود');
        }
        out['plugin'] = name;
        if (opts.isNotEmpty) out['plugin_opts'] = opts;
      }
    }
    return out;
  }

  // ───────────────────────── اجزای مشترک ─────────────────────────

  static Map<String, dynamic> _tls({
    required String sni,
    required String alpn,
    required String fp,
    required bool insecure,
    Map<String, dynamic>? reality,
  }) {
    final tls = <String, dynamic>{'enabled': true};
    if (sni.isNotEmpty) tls['server_name'] = sni;
    if (insecure) tls['insecure'] = true;
    final alpnList = alpn
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    if (alpnList.isNotEmpty) tls['alpn'] = alpnList;
    if (fp.isNotEmpty && fp != 'none') {
      tls['utls'] = {'enabled': true, 'fingerprint': fp};
    }
    if (reality != null) tls['reality'] = reality;
    return tls;
  }

  /// null یعنی ترنسپورت ساده TCP.
  static Map<String, dynamic>? _transport({
    required String net,
    required String headerType,
    required String host,
    required String path,
    required String serviceName,
    required bool tlsOn,
  }) {
    switch (net) {
      case 'tcp':
      case 'raw':
        if (headerType == 'http') {
          return {
            'type': 'http',
            if (host.isNotEmpty) 'host': host.split(',').map((e) => e.trim()).toList(),
            'path': path.isEmpty ? '/' : path,
          };
        }
        return null;
      case 'ws':
      case 'websocket':
        return {
          'type': 'ws',
          'path': path.isEmpty ? '/' : path,
          if (host.isNotEmpty) 'headers': {'Host': host},
        };
      case 'grpc':
        return {'type': 'grpc', 'service_name': serviceName};
      case 'h2':
      case 'http':
        if (!tlsOn) {
          throw const ConfigConvertException('ترنسپورت HTTP/2 بدون TLS');
        }
        return {
          'type': 'http',
          if (host.isNotEmpty) 'host': host.split(',').map((e) => e.trim()).toList(),
          'path': path.isEmpty ? '/' : path,
        };
      case 'httpupgrade':
        return {
          'type': 'httpupgrade',
          if (host.isNotEmpty) 'host': host,
          'path': path.isEmpty ? '/' : path,
        };
      default:
        // xhttp / splithttp / kcp / quic(قدیمی) در Sing-box پشتیبانی نمی‌شوند
        throw ConfigConvertException('ترنسپورت «$net» در Sing-box پشتیبانی نمی‌شود');
    }
  }

  static Uri _uri(String link) {
    final noFragment = link.split('#').first;
    return Uri.parse(noFragment);
  }

  static bool _truthy(String? v) =>
      v != null && (v == '1' || v.toLowerCase() == 'true');

  static String? _b64(String s) {
    try {
      var t = s
          .replaceAll(RegExp(r'\s'), '')
          .replaceAll('-', '+')
          .replaceAll('_', '/');
      if (t.isEmpty) return null;
      t = t + ('=' * ((4 - t.length % 4) % 4));
      return utf8.decode(base64.decode(t), allowMalformed: true);
    } catch (_) {
      return null;
    }
  }
}
