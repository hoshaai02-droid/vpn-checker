import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:flutter_singbox_client/flutter_singbox_client.dart';

import '../models/test_result.dart';
import '../models/vpn_config.dart';
import '../utils/constants.dart';
import '../utils/logger.dart';
import 'singbox_converter.dart';

/// تست واقعی V2Ray با هسته Sing-box (حالت Proxy؛ بدون VpnService و بدون دیالوگ مجوز VPN).
///
/// نکته معماری مهم: هسته Sing-box در این پلاگین «یک نمونه در هر پروسه» است؛
/// یعنی نمی‌شود ۵ هسته جدا همزمان بالا آورد. پس برای همزمانی ۵ تایی:
///   ۱) تست‌ها در یک صف جمع می‌شوند (دسته‌های حداکثر [AppConstants.v2rayConcurrency] تایی)
///   ۲) برای هر دسته «یک» کانفیگ Sing-box ساخته می‌شود که N تا inbound HTTP لوکال
///      (هرکدام روی پورت آزاد خودش) و N تا outbound دارد، و هر inbound فقط به
///      outbound مربوط به خودش وصل است
///   ۳) هسته یک‌بار بالا می‌آید، N درخواست generate_204 موازی از پورت‌های لوکال
///      فرستاده می‌شود، بعد هسته خاموش می‌شود و دسته بعدی شروع می‌شود.
/// از بیرون همان API قبلی (`init()` و `test(c)`) است و provider تقریباً عوض نمی‌شود.
class V2rayTester {
  final SingboxClient _client = SingboxClient();

  bool _ready = false;
  bool _canValidate = false;
  String? lastInitError;
  String _coreVersion = '?';

  StreamSubscription<String>? _faultSub;
  StreamSubscription<List<LogEntry>>? _logSub;
  String? _lastFault;
  final List<String> _coreLines = [];

  final List<_Job> _queue = [];
  Timer? _flushTimer;
  Future<void> _chain = Future.value(); // اجرای دسته‌ها پشت سر هم
  int _seq = 0;
  bool _disposed = false;

  static const Duration _flushDelay = Duration(milliseconds: 600);
  static const Duration _startTimeout = Duration(seconds: 12);
  static const Duration _stopTimeout = Duration(seconds: 10);

  bool get isReady => _ready;

  // ───────────────────────── مقداردهی اولیه ─────────────────────────

  Future<bool> init() async {
    if (_ready) return true;
    lastInitError = null;
    try {
      Log.i('[singbox] initialize…');
      await _client.initialize().timeout(const Duration(seconds: 20));
      _coreVersion = await _client.getCoreVersion();
      Log.i('[singbox] هسته آماده است، نسخه $_coreVersion');

      _faultSub ??= _client.faultStream.listen((m) {
        _lastFault = m;
        Log.e('[singbox][fault] $m');
      });
      _logSub ??= _client.coreLogStream.listen((entries) {
        for (final e in entries) {
          _coreLines.add(e.toString());
          Log.i('[singbox][core] ${e.toString()}');
        }
        if (_coreLines.length > 300) {
          _coreLines.removeRange(0, _coreLines.length - 300);
        }
      });

      // تست سلامت: آیا مرحله «اعتبارسنجی کانفیگ» روی این دستگاه کار می‌کند؟
      try {
        final probe = SingboxConverter.buildBatchConfig([
          (
            tag: 'selftest',
            outbound: <String, dynamic>{
              'type': 'shadowsocks',
              'tag': 'selftest',
              'server': '127.0.0.1',
              'server_port': 9,
              'method': 'aes-128-gcm',
              'password': 'x',
            },
            port: 29999,
          ),
        ]);
        await _client.checkConfig(probe);
        _canValidate = true;
        Log.i('[singbox] checkConfig فعال است');
      } catch (e) {
        _canValidate = false;
        Log.e('[singbox] checkConfig روی کانفیگ سالم خطا داد؛ اعتبارسنجی تکی غیرفعال شد', e);
      }

      _ready = true;
    } catch (e, st) {
      lastInitError = e.toString();
      Log.e('[singbox] راه‌اندازی هسته ناموفق بود', '$e\n$st');
      _ready = false;
    }
    return _ready;
  }

  // ───────────────────────── API اصلی ─────────────────────────

  /// نتیجه یک کانفیگ. صدا زدنش همزمان از چند worker (pool) امن است؛
  /// تست‌ها داخلی در دسته‌های [AppConstants.v2rayConcurrency] تایی اجرا می‌شوند.
  Future<TestResult> test(VpnConfig c) async {
    if (!_ready || _disposed) return const TestResult.fail('هسته آماده نیست');

    // مرحله ۱: تبدیل به JSON مخصوص Sing-box
    final Map<String, dynamic> outbound;
    try {
      outbound = SingboxConverter.outbound(c, 'tmp');
    } on ConfigConvertException catch (e) {
      Log.i('[convert] ${_short(c)} ← رد شد: ${e.message}');
      return TestResult.fail('تبدیل: ${e.message}');
    }

    // مرحله ۲: اعتبارسنجی با خود هسته Go (یک کانفیگ خراب کل دسته را خراب نکند)
    if (_canValidate) {
      try {
        final single = SingboxConverter.buildBatchConfig(
            [(tag: 'tmp', outbound: outbound, port: 29999)]);
        await _client.checkConfig(single);
      } catch (e) {
        Log.i('[validate] ${_short(c)} ← $e');
        return TestResult.fail('کانفیگ نامعتبر: ${_trim(e.toString())}');
      }
    }

    final job = _Job(c, outbound);
    _queue.add(job);
    _scheduleFlush();
    return job.done.future;
  }

  Future<void> dispose() async {
    _disposed = true;
    _flushTimer?.cancel();
    for (final j in _queue) {
      if (!j.done.isCompleted) j.done.complete(const TestResult.fail('لغو شد'));
    }
    _queue.clear();
    try {
      await _chain; // منتظر پایان دسته جاری
    } catch (_) {}
    await _faultSub?.cancel();
    await _logSub?.cancel();
    _faultSub = null;
    _logSub = null;
    try {
      await _ensureIdle();
    } catch (_) {}
  }

  // ───────────────────────── صف و دسته‌بندی ─────────────────────────

  void _scheduleFlush() {
    if (_queue.length >= AppConstants.v2rayConcurrency) {
      _flushNow();
    } else {
      _flushTimer ??= Timer(_flushDelay, _flushNow); // دسته‌های ناقصِ انتهای لیست
    }
  }

  void _flushNow() {
    _flushTimer?.cancel();
    _flushTimer = null;
    while (_queue.isNotEmpty) {
      final n = min(AppConstants.v2rayConcurrency, _queue.length);
      final batch = List<_Job>.from(_queue.sublist(0, n));
      _queue.removeRange(0, n);
      _chain = _chain.then((_) => _runBatch(batch));
    }
  }

  // ───────────────────────── اجرای یک دسته ─────────────────────────

  Future<void> _runBatch(List<_Job> batch, {bool allowSplit = true}) async {
    final seq = ++_seq;
    try {
      final ports = await _freePorts(batch.length);
      final tags = [for (var i = 0; i < batch.length; i++) 'o${seq}_$i'];
      final entries = [
        for (var i = 0; i < batch.length; i++)
          (
            tag: tags[i],
            outbound: <String, dynamic>{...batch[i].outbound, 'tag': tags[i]},
            port: ports[i],
          ),
      ];
      final cfg = SingboxConverter.buildBatchConfig(entries);

      Log.i('[batch $seq] شروع با ${batch.length} کانفیگ، پورت‌ها: $ports');
      _coreLines.clear();
      _lastFault = null;

      final startError = await _start(cfg);
      if (startError != null) {
        Log.e('[batch $seq][مرحله Sing-box] راه‌اندازی هسته ناموفق: $startError');
        await _ensureIdle();
        if (allowSplit && batch.length > 1) {
          Log.i('[batch $seq] تلاش مجدد تک‌به‌تک تا کانفیگ خراب پیدا شود');
          for (final j in batch) {
            await _runBatch([j], allowSplit: false);
          }
          return;
        }
        for (final j in batch) {
          _complete(j, TestResult.fail('Sing-box: ${_trim(startError)}'));
        }
        return;
      }

      // هسته بالاست؛ حالا مرحله HTTP (موازی)
      final results = await Future.wait([
        for (var i = 0; i < batch.length; i++)
          _probe(ports[i], batch[i].c, 'batch $seq'),
      ]);
      await Future.delayed(const Duration(milliseconds: 300)); // رسیدن لاگ‌های هسته

      for (var i = 0; i < batch.length; i++) {
        var r = results[i];
        if (!r.ok) {
          final hint = _coreHint(tags[i]);
          if (hint != null) {
            Log.e('[batch $seq][مرحله Sing-box/outbound] ${_short(batch[i].c)} ← $hint');
            r = TestResult.fail('${r.error ?? 'ناموفق'} | $hint');
          }
        }
        _complete(batch[i], r);
      }
    } catch (e, st) {
      Log.e('[batch $seq] خطای غیرمنتظره', '$e\n$st');
      for (final j in batch) {
        _complete(j, TestResult.fail('خطای داخلی: ${_trim(e.toString())}'));
      }
    } finally {
      try {
        await _ensureIdle();
        await Future.delayed(const Duration(milliseconds: 250)); // آزاد شدن پورت‌ها
      } catch (_) {}
    }
  }

  void _complete(_Job j, TestResult r) {
    if (!j.done.isCompleted) j.done.complete(r);
  }

  // ───────────────────────── مرحله HTTP ─────────────────────────

  /// GET به generate_204 از داخل پروکسی لوکال. ۲۰۴ = سالم.
  /// یک بار تلاش مجدد داخل همان بودجه زمانی (برای نوسان‌های اینترنت ایران).
  Future<TestResult> _probe(int port, VpnConfig c, String label) async {
    final deadline = DateTime.now().add(AppConstants.v2rayTimeout);
    var lastErr = 'Timeout';

    for (var attempt = 1; attempt <= 2; attempt++) {
      final left = deadline.difference(DateTime.now());
      if (left <= const Duration(milliseconds: 500)) break;

      final sw = Stopwatch()..start();
      final http = HttpClient()
        ..findProxy = ((_) => 'PROXY 127.0.0.1:$port') // https با CONNECT از inbound لوکال
        ..connectionTimeout = left
        ..idleTimeout = const Duration(seconds: 1);
      try {
        final req = await http.getUrl(Uri.parse(AppConstants.testUrl)).timeout(left);
        req.headers.set(HttpHeaders.connectionHeader, 'close');
        final left2 = deadline.difference(DateTime.now());
        final resp = await req
            .close()
            .timeout(left2 > Duration.zero ? left2 : const Duration(milliseconds: 1));
        await resp.drain<void>().timeout(const Duration(seconds: 3), onTimeout: () {});
        sw.stop();
        if (resp.statusCode == 204) {
          Log.i('[$label][HTTP] ${_short(c)} OK ${sw.elapsedMilliseconds}ms (تلاش $attempt)');
          return TestResult.success(max(1, sw.elapsedMilliseconds));
        }
        lastErr = 'HTTP ${resp.statusCode}';
      } on TimeoutException {
        lastErr = 'Timeout (${AppConstants.v2rayTimeout.inSeconds}s)';
      } on SocketException catch (e) {
        lastErr = 'Socket: ${_trim(e.message)}';
      } on HandshakeException catch (e) {
        lastErr = 'TLS: ${_trim(e.message)}';
      } on HttpException catch (e) {
        lastErr = 'HTTP: ${_trim(e.message)}';
      } catch (e) {
        lastErr = _trim(e.toString());
      } finally {
        http.close(force: true);
      }
      Log.i('[$label][HTTP] ${_short(c)} FAIL تلاش $attempt ← $lastErr');
      if (attempt == 1) await Future.delayed(const Duration(milliseconds: 400));
    }
    return TestResult.fail('HTTP: $lastErr');
  }

  // ───────────────────────── کنترل سرویس ─────────────────────────

  /// null = هسته با موفقیت بالا آمد؛ در غیر این صورت متن خطا.
  Future<String?> _start(String cfg) async {
    await _ensureIdle();
    try {
      await _client.connect(SessionOptions(
        config: cfg,
        networkMode: NetworkMode.proxy, // بدون TUN و بدون مجوز VPN
        notification: const NotificationConfig(
          title: 'VPN Config Checker',
          channelName: 'Config test',
        ),
      ));
    } catch (e) {
      return 'connect: $e';
    }

    final deadline = DateTime.now().add(_startTimeout);
    while (DateTime.now().isBefore(deadline)) {
      final st = await _client.getServiceState();
      if (st.isRunning) return null;
      if (_lastFault != null) return _lastFault;
      await Future.delayed(const Duration(milliseconds: 150));
    }
    return _lastFault ?? 'هسته در ${_startTimeout.inSeconds} ثانیه بالا نیامد';
  }

  /// مطمئن می‌شود سرویس خاموش است (در صورت نیاز disconnect می‌زند).
  Future<void> _ensureIdle() async {
    final deadline = DateTime.now().add(_stopTimeout);
    var disconnectSent = false;
    while (DateTime.now().isBefore(deadline)) {
      final st = await _client.getServiceState();
      if (st.isIdle) return;
      if (st.isRunning && !disconnectSent) {
        try {
          await _client.disconnect();
          disconnectSent = true;
        } catch (e) {
          Log.e('[singbox] disconnect خطا داد', e);
        }
      }
      await Future.delayed(const Duration(milliseconds: 150));
    }
    Log.e('[singbox] سرویس در ${_stopTimeout.inSeconds}s خاموش نشد');
  }

  // ───────────────────────── ابزارها ─────────────────────────

  Future<List<int>> _freePorts(int n) async {
    final socks = <ServerSocket>[];
    try {
      for (var i = 0; i < n; i++) {
        socks.add(await ServerSocket.bind(InternetAddress.loopbackIPv4, 0));
      }
      return socks.map((s) => s.port).toList();
    } finally {
      for (final s in socks) {
        await s.close();
      }
    }
  }

  /// اولین خط لاگ هسته که به این outbound/inbound مربوط است (علت دقیق شکست).
  String? _coreHint(String tag) {
    for (final l in _coreLines) {
      if (l.contains(tag)) return _trim(l, 140);
    }
    return null;
  }

  String _short(VpnConfig c) => '${c.protocol.label} ${c.host}:${c.port}';

  String _trim(String s, [int maxLen = 100]) {
    final t = s.replaceAll('\n', ' ').trim();
    return t.length <= maxLen ? t : '${t.substring(0, maxLen)}…';
  }
}

class _Job {
  final VpnConfig c;
  final Map<String, dynamic> outbound;
  final Completer<TestResult> done = Completer<TestResult>();
  _Job(this.c, this.outbound);
}
