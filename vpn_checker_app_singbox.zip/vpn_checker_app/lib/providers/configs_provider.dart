import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/test_result.dart';
import '../models/vpn_config.dart';
import '../services/database_service.dart';
import '../services/github_service.dart';
import '../services/openvpn_tester.dart';
import '../services/sstp_tester.dart';
import '../services/v2ray_tester.dart';
import '../utils/constants.dart';
import '../utils/logger.dart';
import '../utils/parser.dart';
import '../utils/pool.dart';
import 'settings_provider.dart';

class ConfigsProvider extends ChangeNotifier {
  final DatabaseService _db = DatabaseService.instance;

  List<VpnConfig> _all = [];
  bool running = false;
  double progress = 0;
  String stage = '';
  int found = 0;
  int okCount = 0;
  int failed = 0;
  String? error;
  List<String> warnings = [];

  final Set<String> activeGroups = {'v2ray', 'openvpn', 'sstp'};
  String search = '';
  bool _cancel = false;

  int get storedCount => _all.length;

  List<VpnConfig> get filtered {
    final q = search.trim().toLowerCase();
    return _all.where((c) {
      if (!activeGroups.contains(c.protocol.group)) return false;
      if (q.isEmpty) return true;
      return c.remark.toLowerCase().contains(q) ||
          c.host.toLowerCase().contains(q) ||
          c.country.toLowerCase().contains(q) ||
          c.protocol.label.toLowerCase().contains(q);
    }).toList();
  }

  Future<void> load() async {
    _all = await _db.activeConfigs();
    try {
      final p = await SharedPreferences.getInstance();
      found = p.getInt('stat_found') ?? 0;
      failed = p.getInt('stat_failed') ?? 0;
      okCount = _all.length;
    } catch (_) {}
    notifyListeners();
  }

  void toggleGroup(String g) {
    if (activeGroups.contains(g)) {
      activeGroups.remove(g);
    } else {
      activeGroups.add(g);
    }
    notifyListeners();
  }

  void setSearch(String s) {
    search = s;
    notifyListeners();
  }

  void cancel() {
    _cancel = true;
    stage = 'در حال لغو…';
    notifyListeners();
  }

  Future<void> clearAll() async {
    await _db.clear();
    _all = [];
    okCount = 0;
    notifyListeners();
  }

  Future<bool> _hasInternet() async {
    try {
      final r = await InternetAddress.lookup('api.github.com')
          .timeout(const Duration(seconds: 8));
      return r.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<String?> _readToken() async {
    try {
      return await appSecureStorage.read(key: githubTokenKey);
    } catch (_) {
      return null;
    }
  }

  /// کل فرآیند: دریافت از گیت‌هاب → تحلیل → تست → ذخیره. هیچ خطایی نباید کرش کند.
  Future<void> refresh() async {
    if (running) return;
    running = true;
    _cancel = false;
    error = null;
    warnings = [];
    progress = 0;
    okCount = 0;
    failed = 0;
    stage = 'بررسی اتصال اینترنت…';
    notifyListeners();

    try {
      if (!await _hasInternet()) {
        error = 'اتصال اینترنت برقرار نیست. اینترنت را بررسی کنید و دوباره امتحان کنید.';
        return;
      }

      final gh = GithubService(token: await _readToken());
      final sources = await gh.fetchAll(
        onProgress: (s, p) {
          stage = s;
          progress = p * 0.3;
          notifyListeners();
        },
        isCancelled: () => _cancel,
      );
      warnings.addAll(gh.warnings);
      if (_cancel) {
        stage = 'لغو شد';
        return;
      }
      if (sources.isEmpty) {
        error = 'هیچ فایلی از گیت‌هاب دریافت نشد.'
            '${warnings.isNotEmpty ? ' (جزئیات در بخش هشدارها)' : ''}';
        return;
      }

      stage = 'تحلیل کانفیگ‌ها…';
      notifyListeners();
      final map = <String, VpnConfig>{};
      for (final s in sources) {
        try {
          for (final c in ConfigParser.parseText(s.text, fileName: s.name)) {
            map.putIfAbsent(c.id, () => c);
          }
        } catch (e) {
          Log.e('تحلیل ${s.name}', e);
        }
      }
      found = map.length;
      if (map.isEmpty) {
        error = 'کانفیگی در فایل‌های دریافت‌شده پیدا نشد.';
        return;
      }

      final v2 = map.values.where((c) => c.protocol.isV2ray).toList()..shuffle();
      final other = map.values.where((c) => !c.protocol.isV2ray).toList()..shuffle();
      final v2List = v2.take(AppConstants.maxV2rayToTest).toList();
      final otherList = other.take(AppConstants.maxOtherToTest).toList();

      // اگر هسته Sing-box بالا نیامد، کل برنامه متوقف نمی‌شود: فقط تست V2Ray
      // رد می‌شود و OpenVPN / SSTP با روش قبلی (TCP / TLS) تست می‌شوند.
      final v2Tester = V2rayTester();
      var v2Usable = v2List;
      if (v2List.isNotEmpty) {
        stage = 'راه‌اندازی هسته Sing-box…';
        notifyListeners();
        if (!await v2Tester.init()) {
          final why = v2Tester.lastInitError ?? 'علت نامشخص';
          Log.e('هسته Sing-box راه‌اندازی نشد؛ تست V2Ray رد شد', why);
          warnings.add('هسته Sing-box راه‌اندازی نشد، پس ${v2List.length} کانفیگ V2Ray '
              'تست نشد (OpenVPN و SSTP تست می‌شوند). علت: $why');
          v2Usable = [];
        }
      }

      final total = v2Usable.length + otherList.length;
      var done = 0;
      final actives = <VpnConfig>[];

      void record(VpnConfig c, TestResult r) {
        done++;
        if (r.ok) {
          c.ok = true;
          c.latencyMs = r.latencyMs;
          c.testedAt = DateTime.now();
          actives.add(c);
          okCount++;
        } else {
          failed++;
        }
        progress = 0.3 + 0.68 * (total == 0 ? 1 : done / total);
        stage = 'تست کانفیگ‌ها ($done از $total)';
        notifyListeners();
      }

      // اول OpenVPN/SSTP (سبک و سریع)، بعد V2Ray؛ تا ترافیک ۴۰ سوکت همزمان
      // روی اینترنت ضعیف باعث تایم‌اوت کاذب در تست‌های Sing-box نشود.
      try {
        await runPool<VpnConfig>(otherList, AppConstants.lightConcurrency, (c) async {
          final r = c.protocol == VpnProtocol.openvpn
              ? await OpenvpnTester.test(c)
              : await SstpTester.test(c);
          record(c, r);
        }, isCancelled: () => _cancel);

        if (v2Usable.isNotEmpty && !_cancel) {
          await runPool<VpnConfig>(v2Usable, AppConstants.v2rayConcurrency, (c) async {
            final r = await v2Tester.test(c);
            if (!r.ok) Log.i('V2Ray ناموفق: ${c.protocol.label} ${c.host}:${c.port} ← ${r.error}');
            record(c, r);
          }, isCancelled: () => _cancel);
        }
      } finally {
        await v2Tester.dispose(); // هسته Sing-box و نوتیفیکیشن سرویس حتماً بسته شود
      }

      if (_cancel) {
        stage = 'لغو شد (نتایج قبلی حفظ شد)';
        return;
      }

      actives.sort((a, b) => a.latencyMs.compareTo(b.latencyMs));
      await _db.replaceAll(actives);
      _all = actives;
      try {
        final p = await SharedPreferences.getInstance();
        await p.setInt('stat_found', found);
        await p.setInt('stat_failed', failed);
      } catch (_) {}
      progress = 1;
      stage = 'پایان؛ ${actives.length} کانفیگ سالم پیدا شد';
    } catch (e, st) {
      Log.e('خطای غیرمنتظره در بروزرسانی', '$e\n$st');
      error = 'خطای غیرمنتظره: $e';
    } finally {
      running = false;
      notifyListeners();
    }
  }
}
